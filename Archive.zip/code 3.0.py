import numpy as np  # Library for numerical arrays and math functions
from scipy.integrate import solve_ivp  # For solving differential equations
import time  # Standard library for timing execution
from scipy.signal import find_peaks  # For detecting spikes in voltage traces
from scipy.fft import fft, fftfreq  # For computing Fast Fourier Transform
import matplotlib.pyplot as plt  # For generating figures

# Define voltage-dependent gating functions for Hodgkin-Huxley model
def alpha_m(V): return 0.1 * (V + 40) / (1 - np.exp(-(V + 40) / 10))  # Activation rate for sodium m gate
def beta_m(V): return 4 * np.exp(-(V + 65) / 18)  # Deactivation rate for sodium m gate
def alpha_h(V): return 0.07 * np.exp(-(V + 65) / 20)  # Activation rate for sodium h gate
def beta_h(V): return 1 / (1 + np.exp(-(V + 35) / 10))  # Deactivation rate for sodium h gate
def alpha_n(V): return 0.01 * (V + 55) / (1 - np.exp(-(V + 55) / 10))  # Activation rate for potassium n gate
def beta_n(V): return 0.125 * np.exp(-(V + 65) / 80)  # Deactivation rate for potassium n gate

# ODE function for Hodgkin-Huxley neuron with time-dependent external current
def hh_ode(t, y, I_mean, g_Na=120, g_K=36, g_L=0.3, E_Na=50, E_K=-77, E_L=-54.4, C_m=1):
    V, m, h, n = y  # Unpack state variables: membrane potential and gating variables
    I_ext = I_mean + 2 * np.sin(2 * np.pi * 6 * t / 1000)  # Sinusoidal theta drive at 6 Hz
    dV = (-g_Na * m**3 * h * (V - E_Na) - g_K * n**4 * (V - E_K) - g_L * (V - E_L) + I_ext) / C_m  # Voltage derivative
    dm = alpha_m(V) * (1 - m) - beta_m(V) * m  # m gate derivative
    dh = alpha_h(V) * (1 - h) - beta_h(V) * h  # h gate derivative
    dn = alpha_n(V) * (1 - n) - beta_n(V) * n  # n gate derivative
    return [dV, dm, dh, dn]  # Return derivatives

# Simulation function for single Leaky Integrate-and-Fire neuron with time-dependent current
def lif_simulation(t_span, dt, tau=20, E_L=-65, R=10, V_th=-55, V_reset=-65, I_mean=0):
    t = np.arange(t_span[0], t_span[1], dt)  # Generate time array
    V = np.zeros(len(t))  # Initialize voltage array
    V[0] = E_L  # Set initial resting potential
    spikes = []  # List to store spike times
    for i in range(1, len(t)):  # Iterate over time steps
        I_ext = I_mean + 0.2 * np.sin(2 * np.pi * 6 * t[i] / 1000)  # Time-varying input (adjusted amplitude)
        V[i] = V[i-1] + dt * (-(V[i-1] - E_L) + R * I_ext) / tau  # Update voltage using Euler method
        if V[i] > V_th:  # Check for spike threshold
            V[i] = V_reset  # Reset voltage
            spikes.append(t[i])  # Record spike time
    return t, V, spikes  # Return time, voltage, and spikes

# Optimized network simulation for Leaky Integrate-and-Fire neurons (modified to return spike times)
def lif_network_simulation(t_span, dt, N=5, p_conn=0.2, tau=20, E_L=-65, R=10, V_th=-55, V_reset=-65, I_mean=1.0, tau_syn=5, g=0.05, E_syn=0):
    t = np.arange(t_span[0], t_span[1], dt)  # Generate time array
    V = np.zeros((len(t), N))  # Initialize voltage matrix
    V[0] = E_L  # Set initial resting potentials
    s = np.zeros((len(t), N, N))  # Synaptic activation matrix (pre, post)
    conn = (np.random.rand(N, N) < p_conn).astype(float)  # Connectivity matrix
    w = g * conn  # Synaptic weights
    spikes_count = np.zeros(N)  # Spike counts per neuron
    spike_times = [[] for _ in range(N)]  # List of lists to store spike times per neuron
    for i in range(1, len(t)):  # Iterate over time steps
        I_ext = I_mean + 0.2 * np.sin(2 * np.pi * 6 * t[i] / 1000) * np.ones(N)  # External input
        gs = np.sum(w * s[i-1], axis=0)  # Summed synaptic conductances
        I_syn = gs * (E_syn - V[i-1])  # Synaptic currents
        V[i] = V[i-1] + dt * (-(V[i-1] - E_L) + R * I_ext + R * I_syn) / tau  # Update voltages
        spiked = V[i] > V_th  # Detect spikes
        for neuron in range(N):  # Record spike times
            if spiked[neuron]:
                spike_times[neuron].append(t[i])
        V[i][spiked] = V_reset  # Reset spiked neurons
        spikes_count[spiked] += 1  # Count spikes
        s[i] = s[i-1] - dt * s[i-1] / tau_syn  # Decay synaptic activations
        s[i] += np.outer(spiked, np.ones(N)) * conn  # Add pulses for spiked neurons
    return t, V, spikes_count, spike_times  # Return time, voltages, spike counts, and spike times

# Set simulation parameters
t_span = [0, 1000]  # Time span in ms
y0 = [-65, 0.05, 0.6, 0.32]  # Initial conditions for HH
I_mean_hh = 7  # Mean input for HH
I_mean_lif = 1.0  # Mean input for LIF
dt = 0.01  # Time step for LIF (can be increased to 0.05 for optimization)

# Execute single HH simulation
start = time.time()
sol_hh = solve_ivp(hh_ode, t_span, y0, args=(I_mean_hh,), method='LSODA', rtol=1e-6)
time_hh = time.time() - start
t_hh, V_hh = sol_hh.t, sol_hh.y[0]
peaks_hh, _ = find_peaks(V_hh, height=0)
spike_rate_hh = len(peaks_hh) / (t_span[1] / 1000)
N_hh = len(t_hh)
yf_hh = fft(V_hh - np.mean(V_hh))
xf_hh = fftfreq(N_hh, t_hh[1] - t_hh[0])
power_hh = np.abs(yf_hh[:N_hh//2])**2
mask_hh = (xf_hh[:N_hh//2] >= 4) & (xf_hh[:N_hh//2] <= 8)
theta_power_hh = np.max(power_hh[mask_hh]) if np.any(mask_hh) else 0
theta_db_hh = 10 * np.log10(theta_power_hh) if theta_power_hh > 0 else 0

# Execute single LIF simulation
start = time.time()
t_lif, V_lif, spikes_lif = lif_simulation(t_span, dt, I_mean=I_mean_lif)
time_lif = time.time() - start
spike_rate_lif = len(spikes_lif) / (t_span[1] / 1000)
N_lif = len(t_lif)
yf_lif = fft(V_lif - np.mean(V_lif))
xf_lif = fftfreq(N_lif, dt)
power_lif = np.abs(yf_lif[:N_lif//2])**2
mask_lif = (xf_lif[:N_lif//2] >= 4) & (xf_lif[:N_lif//2] <= 8)
theta_power_lif = np.max(power_lif[mask_lif]) if np.any(mask_lif) else 0
theta_db_lif = 10 * np.log10(theta_power_lif) if theta_power_lif > 0 else 0

# Execute LIF network simulation (example with p_conn=0.2 for 20% connectivity)
start = time.time()
t_net, V_net, spikes_net, spike_times_net = lif_network_simulation(t_span, dt, p_conn=0.2)
time_net = time.time() - start
mean_spike_net = np.mean(spikes_net) / (t_span[1] / 1000)
LFP_net = np.mean(V_net, axis=1)  # Approximate local field potential as mean voltage
N_net = len(t_net)
yf_net = fft(LFP_net - np.mean(LFP_net))
xf_net = fftfreq(N_net, dt)
power_net = np.abs(yf_net[:N_net//2])**2
mask_net = (xf_net[:N_net//2] >= 4) & (xf_net[:N_net//2] <= 8)
theta_power_net = np.max(power_net[mask_net]) if np.any(mask_net) else 0
theta_db_net = 10 * np.log10(theta_power_net) if theta_power_net > 0 else 0

# Generate Figure 1: Voltage traces
plt.figure(figsize=(10, 6))
plt.subplot(2, 1, 1)
plt.plot(t_hh, V_hh, label='HH Model')
plt.title('Membrane Potential Dynamics (Single Neuron)')
plt.ylabel('Potential (mV)')
plt.legend()
plt.subplot(2, 1, 2)
plt.plot(t_lif, V_lif, label='LIF Model')
plt.xlabel('Time (ms)')
plt.ylabel('Potential (mV)')
plt.legend()
plt.tight_layout()
plt.savefig('figure1_voltage_traces.png')  # Save for inclusion

# Generate Figure 2: Power spectra
plt.figure(figsize=(10, 6))
plt.subplot(2, 1, 1)
plt.plot(xf_hh[:N_hh//2], 10 * np.log10(power_hh), label='HH Power Spectrum')
plt.title('Power Spectra (Theta Band Highlighted)')
plt.xlim(0, 10)
plt.ylabel('Power (dB)')
plt.legend()
plt.subplot(2, 1, 2)
plt.plot(xf_lif[:N_lif//2], 10 * np.log10(power_lif), label='LIF Power Spectrum')
plt.xlabel('Frequency (Hz)')
plt.xlim(0, 10)
plt.ylabel('Power (dB)')
plt.legend()
plt.tight_layout()
plt.savefig('figure2_power_spectra.png')  # Save for inclusion

# Generate Figure 3: Spike Raster Plot for network (20% connectivity)
plt.figure(figsize=(10, 6))
plt.eventplot(spike_times_net, orientation='horizontal', colors='b')
plt.title('Spike Raster Plot (Network, 20% Connectivity)')
plt.xlabel('Time (ms)')
plt.ylabel('Neuron Index')
plt.tight_layout()
plt.savefig('figure3_raster.png')  # Save for inclusion

# Generate Figure 4: Network Power Spectrum
plt.figure(figsize=(10, 6))
plt.plot(xf_net[:N_net//2], 10 * np.log10(power_net), label='Network Power Spectrum')
plt.axvspan(4, 8, color='yellow', alpha=0.3, label='Theta Band')
plt.axvspan(30, 80, color='green', alpha=0.3, label='Gamma Band')
plt.title('Power Spectrum of Network Local Field Potential')
plt.xlim(0, 100)
plt.xlabel('Frequency (Hz)')
plt.ylabel('Power (dB)')
plt.legend()
plt.tight_layout()
plt.savefig('figure4_network_power.png')  # Save for inclusion