import numpy as np # Library for numerical arrays and math functions
from scipy.integrate import solve_ivp # For solving differential equations
import time # Standard library for timing execution
from scipy.signal import find_peaks # For detecting spikes in voltage traces
from scipy.fft import fft, fftfreq # For computing Fast Fourier Transform
import matplotlib.pyplot as plt # For generating figures
np.random.seed(42) # For reproducibility across runs
# Define voltage-dependent gating functions for Hodgkin-Huxley model
def alpha_m(V): return 0.1 * (V + 40) / (1 - np.exp(-(V + 40) / 10)) # Activation rate for sodium m gate
def beta_m(V): return 4 * np.exp(-(V + 65) / 18) # Deactivation rate for sodium m gate
def alpha_h(V): return 0.07 * np.exp(-(V + 65) / 20) # Activation rate for sodium h gate
def beta_h(V): return 1 / (1 + np.exp(-(V + 35) / 10)) # Deactivation rate for sodium h gate
def alpha_n(V): return 0.01 * (V + 55) / (1 - np.exp(-(V + 55) / 10)) # Activation rate for potassium n gate
def beta_n(V): return 0.125 * np.exp(-(V + 65) / 80) # Deactivation rate for potassium n gate
# ODE function for Hodgkin-Huxley neuron with time-dependent external current
def hh_ode(t, y, I_mean, g_Na=120, g_K=36, g_L=0.3, E_Na=50, E_K=-77, E_L=-54.4, C_m=1):
    V, m, h, n = y # Unpack state variables
    I_ext = I_mean + 2 * np.sin(2 * np.pi * 6 * t / 1000) # Sinusoidal theta drive
    dV = (-g_Na * m**3 * h * (V - E_Na) - g_K * n**4 * (V - E_K) - g_L * (V - E_L) + I_ext) / C_m
    dm = alpha_m(V) * (1 - m) - beta_m(V) * m
    dh = alpha_h(V) * (1 - h) - beta_h(V) * h
    dn = alpha_n(V) * (1 - n) - beta_n(V) * n
    return [dV, dm, dh, dn]
# Simulation function for single Leaky Integrate-and-Fire neuron
def lif_simulation(t_span, dt, tau=20, E_L=-65, R=10, V_th=-55, V_reset=-65, I_mean=0):
    t = np.arange(t_span[0], t_span[1], dt)
    V = np.zeros(len(t))
    V[0] = E_L
    spikes = []
    for i in range(1, len(t)):
        I_ext = I_mean + 0.2 * np.sin(2 * np.pi * 6 * t[i] / 1000)
        V[i] = V[i-1] + dt * (-(V[i-1] - E_L) + R * I_ext) / tau
        if V[i] > V_th:
            V[i] = V_reset
            spikes.append(t[i])
    return t, V, spikes
# Network simulation for Leaky Integrate-and-Fire neurons (8 exc + 2 inh)
def lif_network_simulation(t_span, dt, N_exc=8, N_inh=2, p_conn=0.2, tau=20, E_L=-65, R=10, V_th=-55, V_reset=-65, I_mean=1.0, tau_syn=5, g_exc=0.05, g_inh=0.1):
    N = N_exc + N_inh
    t = np.arange(t_span[0], t_span[1], dt)
    V = np.zeros((len(t), N))
    V[0] = E_L
    s = np.zeros((len(t), N, N))
    conn_exc = (np.random.rand(N_exc, N) < p_conn).astype(float)
    conn_inh = (np.random.rand(N_inh, N) < p_conn).astype(float)
    conn = np.vstack((conn_exc, conn_inh))
    w = np.zeros_like(conn)
    w[:N_exc] = g_exc * conn_exc
    w[N_exc:] = -g_inh * conn_inh
    E_syn_vec = np.array([0] * N_exc + [-80] * N_inh)
    spikes_count = np.zeros(N)
    for i in range(1, len(t)):
        I_ext = I_mean + 0.2 * np.sin(2 * np.pi * 6 * t[i] / 1000) * np.ones(N)
        g_s = w * s[i-1]
        deltaV = E_syn_vec[:, np.newaxis] - V[i-1][np.newaxis, :]
        I_syn = np.sum(g_s * deltaV, axis=0)
        V[i] = V[i-1] + dt * (-(V[i-1] - E_L) + R * (I_ext + I_syn)) / tau
        spiked = V[i] > V_th
        V[i][spiked] = V_reset
        spikes_count[spiked] += 1
        s[i] = s[i-1] - dt * s[i-1] / tau_syn
        s[i] += np.outer(spiked, np.ones(N)) * conn
    return t, V, spikes_count
# Set simulation parameters
t_span = [0, 1000]
y0 = [-65, 0.05, 0.6, 0.32]
I_mean_hh = 7
I_mean_lif = 1.0
dt = 0.01
dt_opt = 0.02 # Intermediate for balance
# Function to compute metrics
def compute_metrics(V, t, dt_or_diff):
    yf = fft(V - np.mean(V))
    xf = fftfreq(len(t), dt_or_diff)
    power = np.abs(yf[:len(t)//2])**2
    mask_theta = (4 <= xf[:len(t)//2] <= 8)
    mask_gamma = (30 <= xf[:len(t)//2] <= 80)
    theta_db = 10 * np.log10(np.max(power[mask_theta])) if np.any(mask_theta) else 0
    gamma_db = 10 * np.log10(np.max(power[mask_gamma])) if np.any(mask_gamma) else 0
    return theta_db, gamma_db
# Run simulations and average over 5 runs (for SD)
def run_and_average(sim_func, *args, runs=5):
    rates = []
    times = []
    theta_dbs = []
    gamma_dbs = []
    for _ in range(runs):
        start = time.time()
        t, V, spikes = sim_func(*args)
        time_taken = time.time() - start
        if sim_func == lif_network_simulation:
            mean_rate = np.mean(spikes) / (t_span[1] / 1000)
            LFP = np.mean(V, axis=1)
            theta_db, gamma_db = compute_metrics(LFP, t, args[1]) # dt
        else:
            mean_rate = len(spikes) / (t_span[1] / 1000)
            theta_db, gamma_db = compute_metrics(V, t, args[1]) # dt
        rates.append(mean_rate)
        times.append(time_taken)
        theta_dbs.append(theta_db)
        gamma_dbs.append(gamma_db)
    return np.mean(rates), np.std(rates), np.mean(times), np.std(times), np.mean(theta_dbs), np.mean(gamma_dbs)
# HH single (no SD as deterministic)
start = time.time()
sol_hh = solve_ivp(hh_ode, t_span, y0, args=(I_mean_hh,), method='LSODA', rtol=1e-6)
time_hh = time.time() - start
t_hh, V_hh = sol_hh.t, sol_hh.y[0]
peaks_hh, _ = find_peaks(V_hh, height=0)
spike_rate_hh = len(peaks_hh) / (t_span[1] / 1000)
theta_db_hh, gamma_db_hh = compute_metrics(V_hh, t_hh, t_hh[1] - t_hh[0])
# LIF single dt=0.01
spike_rate_lif, _, time_lif, _, theta_db_lif, gamma_db_lif = run_and_average(lif_simulation, t_span, dt, I_mean=I_mean_lif)
# LIF single optimized dt=0.02
spike_rate_lif_opt, _, time_lif_opt, _, theta_db_lif_opt, gamma_db_lif_opt = run_and_average(lif_simulation, t_span, dt_opt, I_mean=I_mean_lif)
# LIF network p=0.2
spike_rate_net, sd_rate_net, time_net, sd_time_net, theta_db_net, gamma_db_net = run_and_average(lif_network_simulation, t_span, dt, p_conn=0.2)
# LIF network sparsified p=0.14
spike_rate_net_sp, sd_rate_net_sp, time_net_sp, sd_time_net_sp, theta_db_net_sp, gamma_db_net_sp = run_and_average(lif_network_simulation, t_span, dt, p_conn=0.14)
# Generate Figure 1 with caption (voltage traces for single)
plt.figure(figsize=(10, 6))
plt.subplot(2, 1, 1)
plt.plot(t_hh, V_hh, label='HH Model')
plt.title('Membrane Potential Dynamics (Single Neuron)')
plt.ylabel('Potential (mV)')
plt.legend()
plt.subplot(2, 1, 2)
plt.plot(t_lif, V_lif, label='LIF Model')
plt.xlabel('Time (ms)')
plt.ylabel('Potential (mV)')
plt.legend()
plt.tight_layout()
plt.savefig('figure1_voltage_traces.png')
# Figure 2: Power spectra with annotations
plt.figure(figsize=(10, 6))
plt.subplot(2, 1, 1)
plt.plot(xf_hh[:len(t_hh)//2], 10 * np.log10(power_hh), label='HH Power Spectrum')
plt.axvline(x=6, color='r', linestyle='--', label='6 Hz Peak')
plt.title('Power Spectra (Theta Band Highlighted)')
plt.xlim(0, 10)
plt.ylabel('Power (dB)')
plt.legend()
plt.subplot(2, 1, 2)
plt.plot(xf_lif[:len(t_lif)//2], 10 * np.log10(power_lif), label='LIF Power Spectrum')
plt.axvline(x=6, color='r', linestyle='--', label='6 Hz Peak')
plt.xlabel('Frequency (Hz)')
plt.xlim(0, 10)
plt.ylabel('Power (dB)')
plt.legend()
plt.tight_layout()
plt.savefig('figure2_power_spectra.png')
