import numpy as np
from scipy.integrate import solve_ivp
import time
from scipy.signal import find_peaks
from scipy.fft import fft, fftfreq
import matplotlib.pyplot as plt

# Define voltage-dependent gating functions for Hodgkin-Huxley model
def alpha_m(V): return 0.1 * (V + 40) / (1 - np.exp(-(V + 40) / 10))
def beta_m(V): return 4 * np.exp(-(V + 65) / 18)
def alpha_h(V): return 0.07 * np.exp(-(V + 65) / 20)
def beta_h(V): return 1 / (1 + np.exp(-(V + 35) / 10))
def alpha_n(V): return 0.01 * (V + 55) / (1 - np.exp(-(V + 55) / 10))
def beta_n(V): return 0.125 * np.exp(-(V + 65) / 80)

# ODE function for Hodgkin-Huxley neuron with time-dependent external current
def hh_ode(t, y, I_mean, g_Na=120, g_K=36, g_L=0.3, E_Na=50, E_K=-77, E_L=-54.4, C_m=1):
    V, m, h, n = y
    I_ext = I_mean + 2 * np.sin(2 * np.pi * 6 * t / 1000)
    dV = (-g_Na * m**3 * h * (V - E_Na) - g_K * n**4 * (V - E_K) - g_L * (V - E_L) + I_ext) / C_m
    dm = alpha_m(V) * (1 - m) - beta_m(V) * m
    dh = alpha_h(V) * (1 - h) - beta_h(V) * h
    dn = alpha_n(V) * (1 - n) - beta_n(V) * n
    return [dV, dm, dh, dn]

# Simulation function for single Leaky Integrate-and-Fire neuron with time-dependent current
def lif_simulation(t_span, dt, tau=20, E_L=-65, R=10, V_th=-55, V_reset=-65, I_mean=0):
    t = np.arange(t_span[0], t_span[1], dt)
    V = np.zeros(len(t))
    V[0] = E_L
    spikes = []
    for i in range(1, len(t)):
        I_ext = I_mean + 0.2 * np.sin(2 * np.pi * 6 * t[i] / 1000)
        V[i] = V[i-1] + dt * (-(V[i-1] - E_L) + R * I_ext) / tau
        if V[i] > V_th:
            V[i] = V_reset
            spikes.append(t[i])
    return t, V, spikes

# Network simulation for Leaky Integrate-and-Fire neurons
def lif_network_simulation(t_span, dt, N_exc=8, N_inh=2, p_conn=0.2, tau=20, E_L=-65, R=10, V_th=-55, V_reset=-65, I_mean=1.0, tau_syn=5, g_exc=0.05, g_inh=0.1):
    N = N_exc + N_inh
    t = np.arange(t_span[0], t_span[1], dt)
    V = np.zeros((len(t), N))
    V[0] = E_L
    s = np.zeros((len(t), N, N))
    conn_exc = (np.random.rand(N_exc, N) < p_conn).astype(float)
    conn_inh = (np.random.rand(N_inh, N) < p_conn).astype(float)
    conn = np.vstack((conn_exc, conn_inh))
    w = np.zeros_like(conn)
    w[:N_exc] = g_exc * conn_exc
    w[N_exc:] = -g_inh * conn_inh
    E_syn_vec = np.array([0] * N_exc + [-80] * N_inh)
    spikes_count = np.zeros(N)
    spike_times = [[] for _ in range(N)]
    for i in range(1, len(t)):
        I_ext = I_mean + 0.2 * np.sin(2 * np.pi * 6 * t[i] / 1000) * np.ones(N)
        g_s = w * s[i-1]
        deltaV = E_syn_vec[:, np.newaxis] - V[i-1][np.newaxis, :]
        I_syn = np.sum(g_s * deltaV, axis=0)
        V[i] = V[i-1] + dt * (-(V[i-1] - E_L) + R * (I_ext + I_syn)) / tau
        spiked = V[i] > V_th
        for neuron in range(N):
            if spiked[neuron]:
                spike_times[neuron].append(t[i])
        V[i][spiked] = V_reset
        spikes_count[spiked] += 1
        s[i] = s[i-1] - dt * s[i-1] / tau_syn
        s[i] += np.outer(spiked, np.ones(N)) * conn
    return t, V, spikes_count, spike_times

# Function to compute power in theta (4-8 Hz) and gamma (30-80 Hz) bands (integrated power)
def compute_powers(t, V):
    N = len(V)
    yf = fft(V - np.mean(V))
    xf = fftfreq(N, t[1] - t[0])
    power = np.abs(yf[:N//2])**2
    theta_mask = (xf[:N//2] >= 4) & (xf[:N//2] <= 8)
    gamma_mask = (xf[:N//2] >= 30) & (xf[:N//2] <= 80)
    theta_power = np.sum(power[theta_mask]) if np.any(theta_mask) else 0
    gamma_power = np.sum(power[gamma_mask]) if np.any(gamma_mask) else 0
    theta_db = 10 * np.log10(theta_power) if theta_power > 0 else 0
    gamma_db = 10 * np.log10(gamma_power) if gamma_power > 0 else 0
    return theta_db, gamma_db

# Set simulation parameters
t_span = [0, 1000]
y0 = [-65, 0.05, 0.6, 0.32]
I_mean_hh = 7
I_mean_lif = 1.0
dt_standard = 0.01
dt_optimized = 0.02
num_runs = 5
np.random.seed(42)  # For reproducibility

# Run simulations and collect data
models = [
    ("HH (Single)", lambda: solve_ivp(hh_ode, t_span, y0, args=(I_mean_hh,), method='LSODA', rtol=1e-6), lambda sol: (len(find_peaks(sol.y[0], height=0)[0]) / (t_span[1] / 1000), compute_powers(sol.t, sol.y[0]), sol.t, sol.y[0])),
    ("LIF (Single)", lambda: lif_simulation(t_span, dt_standard, I_mean=I_mean_lif), lambda res: (len(res[2]) / (t_span[1] / 1000), compute_powers(res[0], res[1]), res[0], res[1])),
    ("LIF (Single, Optimized dt=0.02)", lambda: lif_simulation(t_span, dt_optimized, I_mean=I_mean_lif), lambda res: (len(res[2]) / (t_span[1] / 1000), compute_powers(res[0], res[1]), res[0], res[1])),
    ("LIF Network (20%)", lambda: lif_network_simulation(t_span, dt_standard, p_conn=0.2), lambda res: (np.mean(res[2]) / (t_span[1] / 1000), compute_powers(res[0], np.mean(res[1], axis=1)), res[0], np.mean(res[1], axis=1))),
    ("LIF Network (Sparsified, 14%)", lambda: lif_network_simulation(t_span, dt_standard, p_conn=0.14), lambda res: (np.mean(res[2]) / (t_span[1] / 1000), compute_powers(res[0], np.mean(res[1], axis=1)), res[0], np.mean(res[1], axis=1)))
]

results = {}
for model_name, sim_func, process_func in models:
    rates = []
    times = []
    theta = []
    gamma = []
    for _ in range(num_runs):
        start = time.time()
        sim_res = sim_func()
        time_taken = time.time() - start
        rate, (theta_db, gamma_db), t, V = process_func(sim_res)
        rates.append(rate)
        times.append(time_taken)
        theta.append(theta_db)
        gamma.append(gamma_db)
    results[model_name] = {
        'rate_mean': np.mean(rates), 'rate_sd': np.std(rates),
        'time_mean': np.mean(times), 'time_sd': np.std(times),
        'theta_mean': np.mean(theta), 'gamma_mean': np.mean(gamma)
    }

# Output the table
print("| Model Type | Spiking Rate (Hz, mean ± SD) | Computation Time (s, mean ± SD) | Theta Power (dB) | Gamma Power (dB) |")
print("|------------|-------------------------------|----------------------------------|-------------------|-------------------|")
for model, data in results.items():
    print(f"| {model} | {data['rate_mean']:.1f} ± {data['rate_sd']:.1f} | {data['time_mean']:.3f} ± {data['time_sd']:.3f} | {data['theta_mean']:.1f} | {data['gamma_mean']:.1f} |")

# Generate and save figures (for completeness, but output is only table)
# Figure 1: Voltage traces (using last run's data for HH and LIF)
hh_t, hh_V = models[0][2](models[0][1]())[-2:]  # From last HH run
lif_t, lif_V = models[1][2](models[1][1]())[-2:]  # From last LIF run
plt.figure(figsize=(10, 6))
plt.subplot(2, 1, 1)
plt.plot(hh_t, hh_V)
plt.title('HH Model Voltage Trace')
plt.subplot(2, 1, 2)
plt.plot(lif_t, lif_V)
plt.title('LIF Model Voltage Trace')
plt.savefig('figure1_voltage_traces.png')

# Similar for other figures...
